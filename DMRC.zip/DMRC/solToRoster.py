import pandas as pd
import csv

# Read the contents of the .sol file
with open("tmFiles/result.sol", "r") as file:
    lines = file.readlines()

# Initialize lists to store data
labels = []
numbers = []

# Parse each line
for line in lines:
    label, number = line.strip().split(" ")  # Split the line into label and number
    labels.append(label)
    numbers.append(int(number))

# Create DataFrame
df = pd.DataFrame({"Label": labels, "Number": numbers})

# Filter rows where Number is 1 and extract the number from the Label
desired_numbers = df[df['Number'] == 1]['Label'].str[1:].astype(int)

print(len(desired_numbers))
# Take only the top 117 numbers
# desired_numbers = list(desired_numbers.head(119))

tookServices = []
dutiesDict = {}

with open("tmFiles/SetOfDuties.csv", 'rb') as file:
    # Read the file content as bytes
    file_content = file.read()
    
    # Replace null bytes with an empty string
    file_content = file_content.replace(b'\x00', b'')
    
    # Convert the modified content back to a string
    file_content = file_content.decode('utf-8')
    
    # Use StringIO to create a file-like object for csv.reader
    from io import StringIO
    file_like_object = StringIO(file_content)
    
    # Create a CSV reader
    reader = csv.reader(file_like_object)
    ijk = 0
    # Iterate over each row and filter out NULL values
    for index, row in enumerate(reader):
        
            
        # Filter out NULL values (assuming NULL is represented as the string 'NULL')
        filtered_row = [int(value) for value in row if value != 'NULL' and value != '']
        #filtered_row = [int(value) if value != '' else None for value in row if value != 'NULL']
        if index < 10:
            print(index, filtered_row)

        
        # if 3 <= len(filtered_row) <= 6:
        #     prob = random.random() < 0.1
        # else: prob = True
        # #Store the filtered row in the dictionary if it's not empty
        # if filtered_row and prob:
        if filtered_row and index in desired_numbers:
            for ii in filtered_row:

                tookServices.append(ii)
                
            # if len(filtered_row) > 1:
            dutiesDict[ijk] = filtered_row
            ijk += 1



print(len((tookServices)))

df = pd.read_csv("inFiles/stepbackServices.csv")#input services

servicesAll = [df.iloc[i,0] for i in range(len(df)) ]



for service in servicesAll:
    if service not in tookServices:
        dutiesDict[ijk] = [service]
        ijk += 1

print(ijk,"yoyooy")

def hhmm2mins(hhmm):
    if True:
        hrs = hhmm[:2]
        min = hhmm[-2:]
        mins = int(hrs)*60 + int(min)
        return mins
    
def min2hhmm(mins):
    """ gives hh:mm string and takes integer minutes 0 to 1440"""
    if True:
        h = mins//60
        mins = mins - (h*60)
        if len(str(h)) == 1: h = "0" + str(h)
        if len(str(mins)) == 1: mins = "0" + str(mins)
        return str(h) + ":" + str(mins)
    
cc1 = ['MKPR','MKPR UP', 'MKPR DN','SAKP','DDSC','DDSC DN','DDSC SDG', 'PVGW','PBGW','PBGW UP','PBGW DN','PVGW UP','PVGW DN','MKPD', 'MKPD ', 'SAKP 3RD']
cc2 = ['SVVR','SVVR DN','MUPR','MUPR DN','MUPR 4TH','MUPR 3RD SDG','KKDA DN', 'KKDA UP','IPE','IPE 3RD','VND','MVPO','MVPO DN','NZM','NIZM', 'KKDA', 'MUPR DN SDG']
crewControl = ['KKDA', 'PVGW', 'KKDA UP','KKDA DN', 'PVGW UP', 'PVGW DN']

def printRoster(dutiesDict, outputFile):
    # global verbose, worstDT
    sameCC = 0
    with open(outputFile, mode='w', newline='') as file:
        writer = csv.writer(file)
        #header = [f"{ordinal(i)} Service" for i in range(1, 20 + 1)]
        #writer.writerow(["Duty No", "Sign On Time", "Sign On Loc", "Sign Off Loc", "Sign Off Time", "Driving Hrs", "Duty Hrs"] + header)
        writer.writerow(["Duty No", "Sign On Time", "Sign On Loc", "Sign Off Loc", "Sign Off Time", "Driving Hrs", "Duty Hrs", "Same Jurisdiction","Rake Num", "Start Stn", "Start Time", "End Stn", "End Time","Service Duration", "Break","StepBack Rake"])


        for index, servSet in dutiesDict.items():
                #print(servSet.breaksTaken,servSet.breaksRemaining,index)
                servSet1 = []
                for ax in servSet:
                    for ss in range(len(df)):
                        if ax == df.iloc[ss,0]:
                            servSet1.append([df.iloc[ss,1],df.iloc[ss,2],df.iloc[ss,3],df.iloc[ss,4],df.iloc[ss,5],df.iloc[ss,6],df.iloc[ss,7],df.iloc[ss,9]])
                

                # dutyDur = min2hhmm(hhmm2mins(servSet1[-1][4]) - hhmm2mins(servSet1[0][2]) + 25)
                # drivingTimes.append(servSet.totalDriveDur)
                # dutyHrs.append(servSet.dutyHrs)
                dutyNo = index
                if servSet1[0][1] in crewControl:
                    signOnTime = min2hhmm(hhmm2mins(servSet1[0][2]) - 15)
                else:
                    signOnTime = min2hhmm(hhmm2mins(servSet1[0][2]) - 25)
                # signOnDur = servSet.signOn()[1]
                signOnLoc = servSet1[0][1]
                if servSet1[-1][3] in crewControl:
                    signOffTime = min2hhmm(hhmm2mins(servSet1[-1][4]) + 10)
                else:
                    signOffTime = min2hhmm(hhmm2mins(servSet1[-1][4]) + 20)
                
                dutyDur = min2hhmm(hhmm2mins(signOffTime) - hhmm2mins(signOnTime))
                signOffLoc = servSet1[-1][3]
                driveDur = min2hhmm(sum([int(sublist[6]) for sublist in servSet1]))
                if (servSet1[0][1] in cc1 and servSet1[-1][3] in cc1) or (servSet1[0][1] in cc2 and servSet1[-1][3] in cc2):
                    sameJuris = "Yes"
                    sameCC += 1
                else: sameJuris = "No"

                breaks = []

# Iterate over the sublists
                for i in range(len(servSet1) - 1):  # Iterate until the second to last sublist
                    diff = hhmm2mins(servSet1[i + 1][2]) - hhmm2mins(servSet1[i][4])  # Calculate the difference
                    breaks.append(diff)
# Rishuv
                First_Serv = True
                brake = 0
                for service in servSet1:
                    if brake == len(servSet1) - 1:
                        new_header = [service[0] , service[1] ,service[2] ,service[3], service[4] , service[6] , 0, service[7]]
                    else:
                        new_header = [service[0] , service[1] ,service[2] ,service[3], service[4] , service[6] , breaks[brake], service[7]]
                        brake += 1
                    if First_Serv:
                        writer.writerow([dutyNo, signOnTime,signOnLoc, signOffLoc, signOffTime, driveDur, dutyDur, sameJuris] + new_header)    
                        First_Serv = False
                    else:
                        #writer.writerow([dutyNo, signOnTime,signOnLoc, signOffLoc, signOffTime, driveDur, dutyDur, sameJuris] + new_header)
                        writer.writerow(["", "","", "", "", "", "",""] + new_header)    
                writer.writerow(["","" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"",""])
    print("same Juris % = ", sameCC/len(dutiesDict))

def ordinal(number): # useful for printing tripChart 
    if 10 <= number % 100 <= 20:
        suffix = 'th'
    else:
        suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(number % 10, 'th')
    return str(number) + suffix

def printChart(dutiesDict, op):
    trainDuty = {}
    for index, servSet in dutiesDict.items():
        servSet1 = []
        for ax in servSet:
            for ss in range(len(df)):
                if ax == df.iloc[ss,0]:
                    servSet1.append([df.iloc[ss,1],df.iloc[ss,2],df.iloc[ss,3],df.iloc[ss,4],df.iloc[ss,5],df.iloc[ss,6],df.iloc[ss,7],df.iloc[ss,9]])
                
        for service in servSet1:
            trainNum = service[0]
            dutyNum = index               
            if trainNum not in trainDuty:
                trainDuty[trainNum] = list()
            trainDuty[trainNum].append([dutyNum,service[1],service[2]])          
           # if service[3] == "KKDA UP":
            #    if service[7] not in trainDuty:
            #        trainDuty[service[7]] = set()
             #   trainDuty[service[7]].add(dutyNum)

    with open(op, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        # Write header
        header = [f"{ordinal(i)} person" for i in range(1, 40 + 1)]
        writer.writerow(['Train No.'] + header)
        # Write data
        for trainNum, dutySet in trainDuty.items():
            dutySet.sort(key=lambda x:x[2])
            writer.writerow([trainNum] + dutySet)


printRoster(dutiesDict, "ouFiles/RosterDMRC.csv")
print("Roster generated and saved in ouFiles")
printChart(dutiesDict, "ouFiles/tripChart.csv")
print("Tripchart generated and saved in ouFiles")
