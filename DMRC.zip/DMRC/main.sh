START_TIME=$SECONDS

# first generate all duties
python crew35.py > tmFiles/SetOfDuties.csv

echo "duties generated"
ELAPSED_TIME=$(($SECONDS - $START_TIME))

echo "Time taken to run crew35.py: $ELAPSED_TIME seconds"

# Generating model

START_TIME1=$SECONDS

python MathematicalModel.py
echo "mathematical model is executed successfully."

ELAPSED_TIME=$(($SECONDS - $START_TIME1))
echo "Time taken to run generate model: $ELAPSED_TIME seconds"

START_TIME1=$SECONDS

gurobi tmFiles/Model.nl method=1 ResultFile=tmFiles/result.sol LogFile=tmFiles/gurobi.log

tail -n+3 tmFiles/result.sol > tmFiles/result1.sol
rm -f tmFiles/result.sol
mv tmFiles/result1.sol tmFiles/result.sol
echo "solver is executed"

ELAPSED_TIME=$(($SECONDS - $START_TIME1))
echo "Time taken to run gurobi: $ELAPSED_TIME seconds"

START_TIME3=$SECONDS

python solToRoster.py

ELAPSED_TIME=$(($SECONDS - $START_TIME3))
echo "Time taken to generate roster from sol: $ELAPSED_TIME seconds"

ELAPSED_TIME=$(($SECONDS - $START_TIME))
echo "Time taken for the whole process: $ELAPSED_TIME seconds"

