#!/bin/bash

# Get the number of lines in the file
length=$(wc -l < "inFiles/stepbackServices.csv")
echo "Total lines: $length"

# Loop from 0 to length-1
for ((i=0; i<length; i++))
do
  # Note: grep does not use the variable directly, use double quotes
  x=$(grep "$i" tmFiles/SetOfDuties.csv | wc -l)

  # Correct spacing and use -eq for integer comparison
  if [ "$x" -eq "0" ]; then
    echo "Line $i has 0 occurrences."
  fi
done

